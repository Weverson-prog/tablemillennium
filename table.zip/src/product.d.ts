
export type TProduct = {
  product?: string;
  fases?: string;
  PCP?: string;
  explosionOf?: string;
  cut?: string;
  checkCut?: string;
  sublimation?: string;
  checkSublimation?: string;
  sew?: string;
  checkSublimation?: string;
  checkSew?: string;
  applyOf?: string;
  passadoria?: string;
  packUp?: string;
  dpa?: string;
};
